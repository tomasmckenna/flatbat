# flatbat
Inspired by https://github.com/CODeRUS/harbour-batteryoverlay

A minimalist tkinter-based system monitor that shows CPU, RAM, GPU, battery, and a clock as thin border overlays.

## Install

### From AUR: 
```bash
yay -S flatbat

