from flatbat.main import run_combined

def run_flatbat():
    """
    Main entry point for flatbat.
    """
    run_combined()
